USE ViitorStudent;
insert into City values ('Bucuresti');
insert into City values ('Craiova');
insert into City values ('Timisoara');
insert into City values('Campina');
insert into City values('Targu Ocna');
insert into City values('Falticeni');
insert into City values('Sibiu');
insert into City values('Constanta');
insert into City values('Brasov');
insert into City values('Dragasani');
insert into City values('Oradea');
insert into City values('Cluj-Napoca');
select * from City