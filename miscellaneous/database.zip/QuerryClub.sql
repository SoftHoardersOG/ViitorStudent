use ViitorStudent
/*
insert into Club([name]) values ('');
*/

insert into Club([name]) values ('Club de robotica');
insert into Club([name]) values ('Club de debate');
insert into Club([name]) values ('Echipa de volei');
insert into Club([name]) values ('Echipa de baschet');
insert into Club([name]) values ('Echipa de fotbal');
insert into Club([name]) values ('Canto');
insert into Club([name]) values ('Instrument muzical');
insert into Club([name]) values ('Cor');
insert into Club([name]) values ('Voluntariat');