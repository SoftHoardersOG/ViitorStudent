use ViitorStudent

/*
insert into UniversityClub([club_id], [university_id])
values (0,0);
*/

/* ROBOTICA */
insert into UniversityClub([club_id], [university_id])
values (1,7);

insert into UniversityClub([club_id], [university_id])
values (1,13);

insert into UniversityClub([club_id], [university_id])
values (1,30);

insert into UniversityClub([club_id], [university_id])
values (1,31);

insert into UniversityClub([club_id], [university_id])
values (1,32);

insert into UniversityClub([club_id], [university_id])
values (1,43);

insert into UniversityClub([club_id], [university_id])
values (1,44);

insert into UniversityClub([club_id], [university_id])
values (1,45);

insert into UniversityClub([club_id], [university_id])
values (1,46);

insert into UniversityClub([club_id], [university_id])
values (1,47);

insert into UniversityClub([club_id], [university_id])
values (1,49);

insert into UniversityClub([club_id], [university_id])
values (1,50);

insert into UniversityClub([club_id], [university_id])
values (1,53);

insert into UniversityClub([club_id], [university_id])
values (1,54);

insert into UniversityClub([club_id], [university_id])
values (1,55);

insert into UniversityClub([club_id], [university_id])
values (1,56);

insert into UniversityClub([club_id], [university_id]) 
values (1,57);


/* debate */

insert into UniversityClub([club_id], [university_id])
values (2,2);

insert into UniversityClub([club_id], [university_id])
values (2,5);

insert into UniversityClub([club_id], [university_id])
values (2,6);

insert into UniversityClub([club_id], [university_id])
values (2,10);

insert into UniversityClub([club_id], [university_id])
values (2,12);

insert into UniversityClub([club_id], [university_id])
values (2,15);

insert into UniversityClub([club_id], [university_id])
values (2,16);

insert into UniversityClub([club_id], [university_id])
values (2,18);

insert into UniversityClub([club_id], [university_id])
values (2,22);

insert into UniversityClub([club_id], [university_id])
values (2,29);

insert into UniversityClub([club_id], [university_id])
values (2,34);

insert into UniversityClub([club_id], [university_id])
values (2,35);

/* echipa de volei */

insert into UniversityClub([club_id], [university_id])
values (3,23);

insert into UniversityClub([club_id], [university_id])
values (3,35);

insert into UniversityClub([club_id], [university_id])
values (3,36);

insert into UniversityClub([club_id], [university_id])
values (3,37);

insert into UniversityClub([club_id], [university_id])
values (3,38);

insert into UniversityClub([club_id], [university_id])
values (3,39);

insert into UniversityClub([club_id], [university_id])
values (3,40);

insert into UniversityClub([club_id], [university_id])
values (3,41);

insert into UniversityClub([club_id], [university_id])
values (3,42);

insert into UniversityClub([club_id], [university_id])
values (3,47);

insert into UniversityClub([club_id], [university_id])
values (3,54);

/* echipa de bascheet */
insert into UniversityClub([club_id], [university_id])
values (4,23);

insert into UniversityClub([club_id], [university_id])
values (4,35);

insert into UniversityClub([club_id], [university_id])
values (4,36);

insert into UniversityClub([club_id], [university_id])
values (4,37);

insert into UniversityClub([club_id], [university_id])
values (4,38);

insert into UniversityClub([club_id], [university_id])
values (4,39);

insert into UniversityClub([club_id], [university_id])
values (4,40);

insert into UniversityClub([club_id], [university_id])
values (4,41);

insert into UniversityClub([club_id], [university_id])
values (4,42);

insert into UniversityClub([club_id], [university_id])
values (4,47);

insert into UniversityClub([club_id], [university_id])
values (4,54);

/*echipa de fotbal*/

insert into UniversityClub([club_id], [university_id])
values (5,23);

insert into UniversityClub([club_id], [university_id])
values (5,35);

insert into UniversityClub([club_id], [university_id])
values (5,36);

insert into UniversityClub([club_id], [university_id])
values (5,37);

insert into UniversityClub([club_id], [university_id])
values (5,38);

insert into UniversityClub([club_id], [university_id])
values (5,39);

insert into UniversityClub([club_id], [university_id])
values (5,40);

insert into UniversityClub([club_id], [university_id])
values (5,41);

insert into UniversityClub([club_id], [university_id])
values (5,42);

insert into UniversityClub([club_id], [university_id])
values (5,47);

insert into UniversityClub([club_id], [university_id])
values (5,54);

/*Canto*/

insert into UniversityClub([club_id], [university_id])
values (6,19);

insert into UniversityClub([club_id], [university_id])
values (6,20);

insert into UniversityClub([club_id], [university_id])
values (6,22);

insert into UniversityClub([club_id], [university_id])
values (6,61);

/*Instrument muzical*/

insert into UniversityClub([club_id], [university_id])
values (7,19);

insert into UniversityClub([club_id], [university_id])
values (7,20);

insert into UniversityClub([club_id], [university_id])
values (7,22);

insert into UniversityClub([club_id], [university_id])
values (7,61);


/*Cor*/

insert into UniversityClub([club_id], [university_id])
values (8,19);

insert into UniversityClub([club_id], [university_id])
values (8,20);

insert into UniversityClub([club_id], [university_id])
values (8,22);

insert into UniversityClub([club_id], [university_id])
values (8,61);


/*Voluntariat*/

insert into UniversityClub([club_id], [university_id])
values (9,15);

insert into UniversityClub([club_id], [university_id])
values (9,16);

insert into UniversityClub([club_id], [university_id])
values (9,17);

insert into UniversityClub([club_id], [university_id])
values (9,18);

insert into UniversityClub([club_id], [university_id])
values (9,19);

insert into UniversityClub([club_id], [university_id])
values (9,20);

insert into UniversityClub([club_id], [university_id])
values (9,28);

insert into UniversityClub([club_id], [university_id])
values (9,30);

insert into UniversityClub([club_id], [university_id])
values (9,49);

insert into UniversityClub([club_id], [university_id])
values (9,59);
SELECT * FROM UniversityClub;
