use ViitorStudent

/*
insert into Interest([name]) values ('');
*/

insert into Interest([name]) values ('Literatura');
insert into Interest([name]) values ('Filosofie');
insert into Interest([name]) values ('Inginerie');
insert into Interest([name]) values ('Programare');
insert into Interest([name]) values ('Muzica');
insert into Interest([name]) values ('Desen');
insert into Interest([name]) values ('Design');
insert into Interest([name]) values ('Sport');
insert into Interest([name]) values ('Tehnologie');
insert into Interest([name]) values ('Compozitie literara');
insert into Interest([name]) values ('Bussiness');
insert into Interest([name]) values ('Domeniul auto');
insert into Interest([name]) values ('Fashion');
insert into Interest([name]) values ('Design interior');
insert into Interest([name]) values ('Lucrul cu animalele');
insert into Interest([name]) values ('Lucrul cu copii');
insert into Interest([name]) values ('Massmedia');
insert into Interest([name]) values ('Psihologie');
insert into Interest([name]) values ('Istorie');