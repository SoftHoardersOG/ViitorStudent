use ViitorStudent

/*
insert into Subject([name]) values ('');
*/
insert into Subject([name]) values ('Fizica');
insert into Subject([name]) values ('Matematica');
insert into Subject([name]) values ('Limba Romana');
insert into Subject([name]) values ('Limba Engleza');
insert into Subject([name]) values ('Limba Germana');
insert into Subject([name]) values ('Limba Franceza');
insert into Subject([name]) values ('Biologie');
insert into Subject([name]) values ('Chimie');
insert into Subject([name]) values ('Religie');
insert into Subject([name]) values ('Educatie fizica');
insert into Subject([name]) values ('Istorie');
insert into Subject([name]) values ('Educatie plastica');
insert into Subject([name]) values ('Muzica');
insert into Subject([name]) values ('Informatica');
insert into Subject([name]) values ('Economie');
insert into Subject([name]) values ('Filosofie');
insert into Subject([name]) values ('Educatie antreprenoriala');
insert into Subject([name]) values ('Limba spaniola');
insert into Subject([name]) values ('Literatura universala');
insert into Subject([name]) values ('Sociologie');
insert into Subject([name]) values ('Psihologie');
insert into Subject([name]) values ('Logica');

select * from Subject;