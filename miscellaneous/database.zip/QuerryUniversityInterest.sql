use ViitorStudent

/*
insert into UniversityInterest([interest_id],[university_id])
values (0,0);
*/

/*Literatura*/
insert into UniversityInterest([interest_id],[university_id])
values (1,6);

insert into UniversityInterest([interest_id],[university_id])
values (1,10);

insert into UniversityInterest([interest_id],[university_id])
values (1,11);

insert into UniversityInterest([interest_id],[university_id])
values (1,12);

insert into UniversityInterest([interest_id],[university_id])
values (1,21);

/*Filosofie*/
insert into UniversityInterest([interest_id],[university_id])
values (2,6);

insert into UniversityInterest([interest_id],[university_id])
values (2,12);

insert into UniversityInterest([interest_id],[university_id])
values (2,21);


/*Inginerie*/

insert into UniversityInterest([interest_id],[university_id])
values (3,43);

insert into UniversityInterest([interest_id],[university_id])
values (3,44);

insert into UniversityInterest([interest_id],[university_id])
values (3,45);

insert into UniversityInterest([interest_id],[university_id])
values (3,49);

insert into UniversityInterest([interest_id],[university_id])
values (3,46);

insert into UniversityInterest([interest_id],[university_id])
values (3,56);

insert into UniversityInterest([interest_id],[university_id])
values (3,54);

insert into UniversityInterest([interest_id],[university_id])
values (3,47);

insert into UniversityInterest([interest_id],[university_id])
values (3,50);

insert into UniversityInterest([interest_id],[university_id])
values (3,53);

insert into UniversityInterest([interest_id],[university_id])
values (3,57);

insert into UniversityInterest([interest_id],[university_id])
values (3,32);

insert into UniversityInterest([interest_id],[university_id])
values (3,31);

insert into UniversityInterest([interest_id],[university_id])
values (3,13);

insert into UniversityInterest([interest_id],[university_id])
values (3,7);

/*Programare*/
insert into UniversityInterest([interest_id],[university_id])
values (4,45);

insert into UniversityInterest([interest_id],[university_id])
values (4,31);

insert into UniversityInterest([interest_id],[university_id])
values (4,46);

insert into UniversityInterest([interest_id],[university_id])
values (4,47);

insert into UniversityInterest([interest_id],[university_id])
values (4,57);

insert into UniversityInterest([interest_id],[university_id])
values (4,54);

insert into UniversityInterest([interest_id],[university_id])
values (4,13);

insert into UniversityInterest([interest_id],[university_id])
values (4,30);

/*Muzica*/

insert into UniversityInterest([interest_id],[university_id])
values (5,22);

insert into UniversityInterest([interest_id],[university_id])
values (5,19);

insert into UniversityInterest([interest_id],[university_id])
values (5,20);

/*Desen*/
insert into UniversityInterest([interest_id],[university_id])
values (6,22);

insert into UniversityInterest([interest_id],[university_id])
values (6,58);

insert into UniversityInterest([interest_id],[university_id])
values (6,60);
/*Design*/
insert into UniversityInterest([interest_id],[university_id])
values (7,22);

insert into UniversityInterest([interest_id],[university_id])
values (7,58);

insert into UniversityInterest([interest_id],[university_id])
values (7,60);
/*Sport*/
insert into UniversityInterest([interest_id],[university_id])
values (8,23);

insert into UniversityInterest([interest_id],[university_id])
values (8,36);

insert into UniversityInterest([interest_id],[university_id])
values (8,37);

insert into UniversityInterest([interest_id],[university_id])
values (8,38);

insert into UniversityInterest([interest_id],[university_id])
values (8,39);

insert into UniversityInterest([interest_id],[university_id])
values (8,40);

insert into UniversityInterest([interest_id],[university_id])
values (8,41);

insert into UniversityInterest([interest_id],[university_id])
values (8,42);

/*Tehnologie*/
insert into UniversityInterest([interest_id],[university_id])
values (9,43);

insert into UniversityInterest([interest_id],[university_id])
values (9,44);

insert into UniversityInterest([interest_id],[university_id])
values (9,45);

insert into UniversityInterest([interest_id],[university_id])
values (9,46);

insert into UniversityInterest([interest_id],[university_id])
values (9,47);

insert into UniversityInterest([interest_id],[university_id])
values (9,48);

insert into UniversityInterest([interest_id],[university_id])
values (9,49);

insert into UniversityInterest([interest_id],[university_id])
values (9,50);

insert into UniversityInterest([interest_id],[university_id])
values (9,51);

insert into UniversityInterest([interest_id],[university_id])
values (9,53);

insert into UniversityInterest([interest_id],[university_id])
values (9,54);

insert into UniversityInterest([interest_id],[university_id])
values (9,56);

insert into UniversityInterest([interest_id],[university_id])
values (9,57);

/*Compozitie literara*/

insert into UniversityInterest([interest_id],[university_id])
values (10,12);

insert into UniversityInterest([interest_id],[university_id])
values (10,21);

insert into UniversityInterest([interest_id],[university_id])
values (10,11);

insert into UniversityInterest([interest_id],[university_id])
values (10,16);

/*Bussinness*/
insert into UniversityInterest([interest_id],[university_id])
values (11,2);

insert into UniversityInterest([interest_id],[university_id])
values (11,30);

insert into UniversityInterest([interest_id],[university_id])
values (11,55);

/*Domeniu auto*/

insert into UniversityInterest([interest_id],[university_id])
values (12,48);


insert into UniversityInterest([interest_id],[university_id])
values (12,49);

/*Fashion*/

insert into UniversityInterest([interest_id],[university_id])
values (13,22);


insert into UniversityInterest([interest_id],[university_id])
values (13,60);

/*Lucru cu animalele*/

insert into UniversityInterest([interest_id],[university_id])
values (15,3);

insert into UniversityInterest([interest_id],[university_id])
values (15,47);

insert into UniversityInterest([interest_id],[university_id])
values (15,54);

insert into UniversityInterest([interest_id],[university_id])
values (15,59);

/*lucru cu copiii*/
insert into UniversityInterest([interest_id],[university_id])
values (16,17);

insert into UniversityInterest([interest_id],[university_id])
values (16,16);

/*Massmedia*/
insert into UniversityInterest([interest_id],[university_id])
values (17,15);

/*Istorie*/
insert into UniversityInterest([interest_id],[university_id])
values (19,10);

insert into UniversityInterest([interest_id],[university_id])
values (19,34);

insert into UniversityInterest([interest_id],[university_id])
values (19,35);

insert into UniversityInterest([interest_id],[university_id])
values (19,36);

insert into UniversityInterest([interest_id],[university_id])
values (19,37);

insert into UniversityInterest([interest_id],[university_id])
values (19,38);

insert into UniversityInterest([interest_id],[university_id])
values (19,39);

insert into UniversityInterest([interest_id],[university_id])
values (19,40);

insert into UniversityInterest([interest_id],[university_id])
values (19,41);

insert into UniversityInterest([interest_id],[university_id])
values (19,42);

/*Psihologie*/

insert into UniversityInterest([interest_id],[university_id])
values (18,16);

insert into UniversityInterest([interest_id],[university_id])
values (19,15);

insert into UniversityInterest([interest_id],[university_id])
values (19,17);

select * from UniversityInterest;