use ViitorStudent

/*
insert into Job([name]) values ('');
*/

insert into Job([name]) values ('Medic');
insert into Job([name]) values ('Ofiter de politie');
insert into Job([name]) values ('Programator');
insert into Job([name]) values ('Ofiter in armata');
insert into Job([name]) values ('Ofiter naval');
insert into Job([name]) values ('Ofiter aerian');
insert into Job([name]) values ('Medic veterinar');
insert into Job([name]) values ('Invatator');
insert into Job([name]) values ('Educator');
insert into Job([name]) values ('Agent de politie');
insert into Job([name]) values ('Jandarm');
insert into Job([name]) values ('Popier');
insert into Job([name]) values ('Agent de penitenciar');
insert into Job([name]) values ('Designer de interior');
insert into Job([name]) values ('Arhitect');
insert into Job([name]) values ('Inginer');
insert into Job([name]) values ('Agent de vanzari');
insert into Job([name]) values ('Psiholog');
insert into Job([name]) values ('Psihiatru');
insert into Job([name]) values ('Antreprenor');
insert into Job([name]) values ('Judecator');
insert into Job([name]) values ('Avocat');
insert into Job([name]) values ('Procuror');
insert into Job([name]) values ('Notar');

Select * from Job;