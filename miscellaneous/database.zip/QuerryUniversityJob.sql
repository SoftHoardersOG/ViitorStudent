use ViitorStudent

/*

insert into UniversityJob([job_id],[university_id])
values (0,0);
*/

/*medic*/
insert into UniversityJob([job_id],[university_id])
values (1,33);

insert into UniversityJob([job_id],[university_id])
values (1,28);

insert into UniversityJob([job_id],[university_id])
values (1,59);

/*ofiter politie*/
insert into UniversityJob([job_id],[university_id])
values (2,34);

insert into UniversityJob([job_id],[university_id])
values (2,35);

insert into UniversityJob([job_id],[university_id])
values (2,36);

insert into UniversityJob([job_id],[university_id])
values (2,37);

insert into UniversityJob([job_id],[university_id])
values (2,38);

insert into UniversityJob([job_id],[university_id])
values (2,39);

insert into UniversityJob([job_id],[university_id])
values (2,40);

insert into UniversityJob([job_id],[university_id])
values (2,41);

insert into UniversityJob([job_id],[university_id])
values (2,42);

/*programator*/

insert into UniversityJob([job_id],[university_id])
values (3,13);

insert into UniversityJob([job_id],[university_id])
values (3,31);

insert into UniversityJob([job_id],[university_id])
values (3,45);

insert into UniversityJob([job_id],[university_id])
values (3,46);

insert into UniversityJob([job_id],[university_id])
values (3,57);

/*ofiter/subofiteri in armata*/

insert into UniversityJob([job_id],[university_id])
values (4,40);

insert into UniversityJob([job_id],[university_id])
values (4,34);

insert into UniversityJob([job_id],[university_id])
values (4,39);

/* Medic veterinar*/

insert into UniversityJob([job_id],[university_id])
values (7,59);

/*invatator*/
insert into UniversityJob([job_id],[university_id])
values (8,16);

/*educator*/
insert into UniversityJob([job_id],[university_id])
values (9,16);

/*agent de politie*/

insert into UniversityJob([job_id],[university_id])
values (10,34);

insert into UniversityJob([job_id],[university_id])
values (10,35);

insert into UniversityJob([job_id],[university_id])
values (10,36);

/*jandarm*/
insert into UniversityJob([job_id],[university_id])
values (11,37);

insert into UniversityJob([job_id],[university_id])
values (11,39);

insert into UniversityJob([job_id],[university_id])
values (11,42);

/*pompier*/
insert into UniversityJob([job_id],[university_id])
values (12,38);

/*agent penitenciar*/

insert into UniversityJob([job_id],[university_id])
values (13,41);

/*dizainar interior*/

insert into UniversityJob([job_id],[university_id])
values (14,22);

insert into UniversityJob([job_id],[university_id])
values (14,60);

/*Arhitect*/

insert into UniversityJob([job_id],[university_id])
values (15,58);

/* inginer */
insert into UniversityJob([job_id],[university_id])
values (16,43);

insert into UniversityJob([job_id],[university_id])
values (16,44);

insert into UniversityJob([job_id],[university_id])
values (16,45);

insert into UniversityJob([job_id],[university_id])
values (16,46);

insert into UniversityJob([job_id],[university_id])
values (16,47);

insert into UniversityJob([job_id],[university_id])
values (16,48);

insert into UniversityJob([job_id],[university_id])
values (16,49);

insert into UniversityJob([job_id],[university_id])
values (16,50);

insert into UniversityJob([job_id],[university_id])
values (16,51);

insert into UniversityJob([job_id],[university_id])
values (16,52);

insert into UniversityJob([job_id],[university_id])
values (16,53);

insert into UniversityJob([job_id],[university_id])
values (16,54);

insert into UniversityJob([job_id],[university_id])
values (16,55);

insert into UniversityJob([job_id],[university_id])
values (16,56);

insert into UniversityJob([job_id],[university_id])
values (16,57);

insert into UniversityJob([job_id],[university_id])
values (16,31);

/*agent vanzari*/
insert into UniversityJob([job_id],[university_id])
values (17,2);

/*psiholog*/
insert into UniversityJob([job_id],[university_id])
values (18,16);

/*psihiatru*/
insert into UniversityJob([job_id],[university_id])
values (19,16);


/*antrepreneur*/
insert into UniversityJob([job_id],[university_id])
values (20,55);

/*judecator, avocat, procuror, notar*/
insert into UniversityJob([job_id],[university_id])
values (22,5);
insert into UniversityJob([job_id],[university_id])
values (22,29);

insert into UniversityJob([job_id],[university_id])
values (23,5);
insert into UniversityJob([job_id],[university_id])
values (23,29);

insert into UniversityJob([job_id],[university_id])
values (24,5);
insert into UniversityJob([job_id],[university_id])
values (24,29);

insert into UniversityJob([job_id],[university_id])
values (25,5);
insert into UniversityJob([job_id],[university_id])
values (25,29);


select * from UniversityJob;