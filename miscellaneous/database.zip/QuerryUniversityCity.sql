use ViitorStudent

/*
insert into UniversityCity([city_id], [university_id]) 
values (,);
*/

insert into UniversityCity([city_id], [university_id]) 
values (1,2);

insert into UniversityCity([city_id], [university_id]) 
values (1,3);

insert into UniversityCity([city_id], [university_id]) 
values (1,4);

insert into UniversityCity([city_id], [university_id]) 
values (1,5);

insert into UniversityCity([city_id], [university_id]) 
values (1,6);

insert into UniversityCity([city_id], [university_id]) 
values (1,7);

insert into UniversityCity([city_id], [university_id]) 
values (1,8);

insert into UniversityCity([city_id], [university_id]) 
values (1,9);

insert into UniversityCity([city_id], [university_id]) 
values (1,10);

insert into UniversityCity([city_id], [university_id]) 
values (1,11);

insert into UniversityCity([city_id], [university_id]) 
values (1,12);

insert into UniversityCity([city_id], [university_id]) 
values (1,13);

insert into UniversityCity([city_id], [university_id]) 
values (1,15);

insert into UniversityCity([city_id], [university_id]) 
values (1,16);

insert into UniversityCity([city_id], [university_id]) 
values (1,17);

insert into UniversityCity([city_id], [university_id]) 
values (1,18);

insert into UniversityCity([city_id], [university_id]) 
values (1,19);

insert into UniversityCity([city_id], [university_id]) 
values (1,20);

insert into UniversityCity([city_id], [university_id]) 
values (2,21);

insert into UniversityCity([city_id], [university_id]) 
values (2,22);

insert into UniversityCity([city_id], [university_id]) 
values (2,23);

insert into UniversityCity([city_id], [university_id]) 
values (2,28);

insert into UniversityCity([city_id], [university_id]) 
values (3,29);

insert into UniversityCity([city_id], [university_id]) 
values (3,30);

insert into UniversityCity([city_id], [university_id]) 
values (2,31);

insert into UniversityCity([city_id], [university_id]) 
values (3,32);

insert into UniversityCity([city_id], [university_id]) 
values (2,33);

insert into UniversityCity([city_id], [university_id]) 
values (1,34);

insert into UniversityCity([city_id], [university_id]) 
values (1,35);

insert into UniversityCity([city_id], [university_id]) 
values (1,36);

insert into UniversityCity([city_id], [university_id]) 
values (1,37);

insert into UniversityCity([city_id], [university_id]) 
values (1,38);

insert into UniversityCity([city_id], [university_id]) 
values (1,39);

insert into UniversityCity([city_id], [university_id]) 
values (7,40);

insert into UniversityCity([city_id], [university_id]) 
values (5,41);

insert into UniversityCity([city_id], [university_id]) 
values (10,42);

insert into UniversityCity([city_id], [university_id]) 
values (1,43);

insert into UniversityCity([city_id], [university_id]) 
values (1,44);

insert into UniversityCity([city_id], [university_id]) 
values (1,45);

insert into UniversityCity([city_id], [university_id]) 
values (1,46);

insert into UniversityCity([city_id], [university_id]) 
values (1,47);

insert into UniversityCity([city_id], [university_id]) 
values (1,48);

insert into UniversityCity([city_id], [university_id]) 
values (1,49);

insert into UniversityCity([city_id], [university_id]) 
values (1,50);

insert into UniversityCity([city_id], [university_id]) 
values (1,51);

insert into UniversityCity([city_id], [university_id]) 
values (1,52);

insert into UniversityCity([city_id], [university_id]) 
values (1,53);

insert into UniversityCity([city_id], [university_id]) 
values (1,54);

insert into UniversityCity([city_id], [university_id]) 
values (1,55);

insert into UniversityCity([city_id], [university_id]) 
values (1,56);

insert into UniversityCity([city_id], [university_id]) 
values (1,57);


SELECT * FROM UniversityCity