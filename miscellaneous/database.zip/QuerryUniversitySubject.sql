use ViitorStudent

/*
insert into UniversitySubject([subject_id], [university_id])
values (0,0);
*/

/*Fizica*/
insert into UniversitySubject([subject_id], [university_id])
values (1,7);
insert into UniversitySubject([subject_id], [university_id])
values (1,31);
insert into UniversitySubject([subject_id], [university_id])
values (1,43);
insert into UniversitySubject([subject_id], [university_id])
values (1,44);
insert into UniversitySubject([subject_id], [university_id])
values (1,45);
insert into UniversitySubject([subject_id], [university_id])
values (1,46);
insert into UniversitySubject([subject_id], [university_id])
values (1,47);
insert into UniversitySubject([subject_id], [university_id])
values (1,48);
insert into UniversitySubject([subject_id], [university_id])
values (1,49);
insert into UniversitySubject([subject_id], [university_id])
values (1,50);
insert into UniversitySubject([subject_id], [university_id])
values (1,51);
insert into UniversitySubject([subject_id], [university_id])
values (1,52);
insert into UniversitySubject([subject_id], [university_id])
values (1,53);
insert into UniversitySubject([subject_id], [university_id])
values (1,54);
insert into UniversitySubject([subject_id], [university_id])
values (1,55);
insert into UniversitySubject([subject_id], [university_id])
values (1,56);
insert into UniversitySubject([subject_id], [university_id])
values (1,57);

/*Matematica*/
insert into UniversitySubject([subject_id], [university_id])
values (2,13);
insert into UniversitySubject([subject_id], [university_id])
values (2,31);
insert into UniversitySubject([subject_id], [university_id])
values (2,32);
insert into UniversitySubject([subject_id], [university_id])
values (2,43);
insert into UniversitySubject([subject_id], [university_id])
values (2,44);
insert into UniversitySubject([subject_id], [university_id])
values (2,45);
insert into UniversitySubject([subject_id], [university_id])
values (2,46);
insert into UniversitySubject([subject_id], [university_id])
values (2,47);
insert into UniversitySubject([subject_id], [university_id])
values (2,48);
insert into UniversitySubject([subject_id], [university_id])
values (2,49);
insert into UniversitySubject([subject_id], [university_id])
values (2,50);
insert into UniversitySubject([subject_id], [university_id])
values (2,51);
insert into UniversitySubject([subject_id], [university_id])
values (2,52);
insert into UniversitySubject([subject_id], [university_id])
values (2,53);
insert into UniversitySubject([subject_id], [university_id])
values (2,54);
insert into UniversitySubject([subject_id], [university_id])
values (2,55);
insert into UniversitySubject([subject_id], [university_id])
values (2,56);
insert into UniversitySubject([subject_id], [university_id])
values (2,57);

/*Limba romana*/
insert into UniversitySubject([subject_id], [university_id])
values (3,5);
insert into UniversitySubject([subject_id], [university_id])
values (3,12);
insert into UniversitySubject([subject_id], [university_id])
values (3,15);
insert into UniversitySubject([subject_id], [university_id])
values (3,18);
insert into UniversitySubject([subject_id], [university_id])
values (3,21);
insert into UniversitySubject([subject_id], [university_id])
values (3,29);
insert into UniversitySubject([subject_id], [university_id])
values (3,34);
insert into UniversitySubject([subject_id], [university_id])
values (3,35);
insert into UniversitySubject([subject_id], [university_id])
values (3,36);
insert into UniversitySubject([subject_id], [university_id])
values (3,37);
insert into UniversitySubject([subject_id], [university_id])
values (3,38);
insert into UniversitySubject([subject_id], [university_id])
values (3,39);
insert into UniversitySubject([subject_id], [university_id])
values (3,40);
insert into UniversitySubject([subject_id], [university_id])
values (3,41);
insert into UniversitySubject([subject_id], [university_id])
values (3,42);

/*Limba engleza*/
insert into UniversitySubject([subject_id], [university_id])
values (4,11);
insert into UniversitySubject([subject_id], [university_id])
values (4,12);
insert into UniversitySubject([subject_id], [university_id])
values (4,15);
insert into UniversitySubject([subject_id], [university_id])
values (4,21);
insert into UniversitySubject([subject_id], [university_id])
values (4,35);
insert into UniversitySubject([subject_id], [university_id])
values (4,36);
insert into UniversitySubject([subject_id], [university_id])
values (4,37);
insert into UniversitySubject([subject_id], [university_id])
values (4,38);
insert into UniversitySubject([subject_id], [university_id])
values (4,52);

/*Limba germana*/
insert into UniversitySubject([subject_id], [university_id])
values (5,11);
insert into UniversitySubject([subject_id], [university_id])
values (5,12);
insert into UniversitySubject([subject_id], [university_id])
values (5,21);
insert into UniversitySubject([subject_id], [university_id])
values (5,52);


/*Limba franceza*/
insert into UniversitySubject([subject_id], [university_id])
values (6,11);
insert into UniversitySubject([subject_id], [university_id])
values (6,12);
insert into UniversitySubject([subject_id], [university_id])
values (6,21);
insert into UniversitySubject([subject_id], [university_id])
values (6,52);
insert into UniversitySubject([subject_id], [university_id])
values (6,5);

/*Biologie*/
insert into UniversitySubject([subject_id], [university_id])
values (7,3);
insert into UniversitySubject([subject_id], [university_id])
values (7,23);
insert into UniversitySubject([subject_id], [university_id])
values (7,28);
insert into UniversitySubject([subject_id], [university_id])
values (7,33);
insert into UniversitySubject([subject_id], [university_id])
values (7,47);
insert into UniversitySubject([subject_id], [university_id])
values (7,54);

/*Chimie*/
insert into UniversitySubject([subject_id], [university_id])
values (8,4);
insert into UniversitySubject([subject_id], [university_id])
values (8,9);
insert into UniversitySubject([subject_id], [university_id])
values (8,28);
insert into UniversitySubject([subject_id], [university_id])
values (8,33);
insert into UniversitySubject([subject_id], [university_id])
values (8,50);
insert into UniversitySubject([subject_id], [university_id])
values (8,51);

/*Religie*/
insert into UniversitySubject([subject_id], [university_id])
values (9,19);
insert into UniversitySubject([subject_id], [university_id])
values (9,20);

/*Educatie fizica*/
insert into UniversitySubject([subject_id], [university_id])
values (10,23);
insert into UniversitySubject([subject_id], [university_id])
values (10,34);
insert into UniversitySubject([subject_id], [university_id])
values (10,35);
insert into UniversitySubject([subject_id], [university_id])
values (10,36);
insert into UniversitySubject([subject_id], [university_id])
values (10,37);
insert into UniversitySubject([subject_id], [university_id])
values (10,38);
insert into UniversitySubject([subject_id], [university_id])
values (10,39);
insert into UniversitySubject([subject_id], [university_id])
values (10,40);
insert into UniversitySubject([subject_id], [university_id])
values (10,41);
insert into UniversitySubject([subject_id], [university_id])
values (10,42);

/*Istorie*/
insert into UniversitySubject([subject_id], [university_id])
values (11,10);
insert into UniversitySubject([subject_id], [university_id])
values (11,34);
insert into UniversitySubject([subject_id], [university_id])
values (11,35);
insert into UniversitySubject([subject_id], [university_id])
values (11,36);
insert into UniversitySubject([subject_id], [university_id])
values (11,37);
insert into UniversitySubject([subject_id], [university_id])
values (11,38);
insert into UniversitySubject([subject_id], [university_id])
values (11,39);
insert into UniversitySubject([subject_id], [university_id])
values (11,40);
insert into UniversitySubject([subject_id], [university_id])
values (11,41);
insert into UniversitySubject([subject_id], [university_id])
values (11,42);

/*Educatie plastica*/
insert into UniversitySubject([subject_id], [university_id])
values (12,22);
insert into UniversitySubject([subject_id], [university_id])
values (12,58);
insert into UniversitySubject([subject_id], [university_id])
values (12,60);
/*Muzica*/
insert into UniversitySubject([subject_id], [university_id])
values (13,22);
insert into UniversitySubject([subject_id], [university_id])
values (13,61);

/*Informatica*/
insert into UniversitySubject([subject_id], [university_id])
values (14,13);
insert into UniversitySubject([subject_id], [university_id])
values (14,31);
insert into UniversitySubject([subject_id], [university_id])
values (14,30);
insert into UniversitySubject([subject_id], [university_id])
values (14,43);
insert into UniversitySubject([subject_id], [university_id])
values (14,44);
insert into UniversitySubject([subject_id], [university_id])
values (14,45);
insert into UniversitySubject([subject_id], [university_id])
values (14,46);
insert into UniversitySubject([subject_id], [university_id])
values (14,47);
insert into UniversitySubject([subject_id], [university_id])
values (14,48);
insert into UniversitySubject([subject_id], [university_id])
values (14,49);
insert into UniversitySubject([subject_id], [university_id])
values (14,50);
insert into UniversitySubject([subject_id], [university_id])
values (14,51);
insert into UniversitySubject([subject_id], [university_id])
values (14,52);
insert into UniversitySubject([subject_id], [university_id])
values (14,53);
insert into UniversitySubject([subject_id], [university_id])
values (14,54);
insert into UniversitySubject([subject_id], [university_id])
values (14,55);
insert into UniversitySubject([subject_id], [university_id])
values (14,56);
insert into UniversitySubject([subject_id], [university_id])
values (14,57);

/*Economie*/
insert into UniversitySubject([subject_id], [university_id])
values (15,2);
insert into UniversitySubject([subject_id], [university_id])
values (15,18);
insert into UniversitySubject([subject_id], [university_id])
values (15,30);
insert into UniversitySubject([subject_id], [university_id])
values (15,5);
insert into UniversitySubject([subject_id], [university_id])
values (15,55);

/*Filosofie*/
insert into UniversitySubject([subject_id], [university_id])
values (16,6);
insert into UniversitySubject([subject_id], [university_id])
values (16,12);
insert into UniversitySubject([subject_id], [university_id])
values (16,21);

/*Educatie antreprenoriala*/
insert into UniversitySubject([subject_id], [university_id])
values (17,2);
insert into UniversitySubject([subject_id], [university_id])
values (17,55);

/*Limba spaniola*/
insert into UniversitySubject([subject_id], [university_id])
values (18,11);
insert into UniversitySubject([subject_id], [university_id])
values (18,12);
insert into UniversitySubject([subject_id], [university_id])
values (18,21);
insert into UniversitySubject([subject_id], [university_id])
values (18,52);

/*Literatura universala*/
insert into UniversitySubject([subject_id], [university_id])
values (19,6);
insert into UniversitySubject([subject_id], [university_id])
values (19,10);
insert into UniversitySubject([subject_id], [university_id])
values (19,11);
insert into UniversitySubject([subject_id], [university_id])
values (19,12);
insert into UniversitySubject([subject_id], [university_id])
values (19,19);
insert into UniversitySubject([subject_id], [university_id])
values (19,20);
insert into UniversitySubject([subject_id], [university_id])
values (19,21);

/*Sociologie*/
insert into UniversitySubject([subject_id], [university_id])
values (20,16);
insert into UniversitySubject([subject_id], [university_id])
values (20,17);
insert into UniversitySubject([subject_id], [university_id])
values (20,18);

/*Psihologie*/
insert into UniversitySubject([subject_id], [university_id])
values (21,16);
insert into UniversitySubject([subject_id], [university_id])
values (21,17);

/*Logica*/
insert into UniversitySubject([subject_id], [university_id])
values (22,5);
insert into UniversitySubject([subject_id], [university_id])
values (22,29);

select * from UniversitySubject;